# kristpy

This is a python library for the Krist websocket API
Currently it only supports making and recieving transactions of type `Transfer` but may support more in the future
